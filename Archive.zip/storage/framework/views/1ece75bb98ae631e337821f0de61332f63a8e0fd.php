<?php $__env->startSection('content'); ?>

    <!--Shop Page Section-->
    <section class="shop-page-section">
        <div class="auto-container">
            <div class="sec-title">
                <h3 class="font-weight-bold text-uppercase"><?php echo e($category->name); ?></h3>
            </div>

            <div class="row clearfix">
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Shop Item-->
                    <div class="shop-item col-lg-3 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="<?php echo e(route('product',['id' => $product->id, 'slug' => str_slug($product->name, '-')])); ?>"><img src="<?php echo e(asset('products')); ?>/<?php echo e($product->image); ?>" alt="" /></a>
                            </div>
                            <div class="lower-content">
                                <h3><a href="<?php echo e(route('product',['id' => $product->id, 'slug' => str_slug($product->name, '-')])); ?>"><?php echo e($product->name); ?></a></h3>


                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </section>
    <!--End Shop Page Section-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>